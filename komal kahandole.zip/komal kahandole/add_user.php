<?php
session_start();
include('db_conn.php');
//get data from sign page 
$name = $_POST['name'];
$phone = $_POST['phoneno'];
$email = $_POST['email'];
$password = $_POST['pass2'];
$address = $_POST['address'];

//Createing verfiction code
$v_cod=bin2hex(random_bytes(16));


//insert query
$int = "INSERT INTO `user`(`name`, `address`, `phoneno`, `email`, `password`, `verification_id`, `verification_status`) 
                 VALUES ('$name', '$address', '$phone', '$email', '$password', '$v_cod','0')";
$res = mysqli_query($conn, $int);

if ($res) {
    echo '<script>alert(" User Created sucessfully");window.location.assign("index.html"); </script>';

   

} else {
    echo '<script>alert(" Please fill the correct data"); </script>';
}

$to_email = $email;
$subject = "Simple Email Test via PHP";
$body = "Hi, This is test email send by PHP Script";
$headers = "From: sender email";

if (mail($to_email, $subject, $body, $headers)) {
    echo "Email successfully sent to $to_email...";
} else {
    echo "Email sending failed...";
}
?>
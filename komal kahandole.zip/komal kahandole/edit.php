<?php
session_start();

    include('db_conn.php');  
    $name = $_POST['name'];
    $phoneno = $_POST['phoneno'];
    $email = $_POST['email'];
      
        $sql = "UPDATE `user` SET `name`='$name',`phoneno`='$phoneno',
        `email`='$email',`password`='[value-5]',`verification_id`='[value-6]',
        `verification_status`='[value-7]' WHERE ";  
             
        if($conn->query($sql) === TRUE){  
          echo '<script>alert("Password update successfully");window.location.assign("home.php");</script>';  
          die();
        }  
        else{  
            echo '<script>alert("Invalid Date");window.location.assign("index.php");</script>';  
        } 
   
?>  
 
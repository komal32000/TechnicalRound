<?php
session_start();

    include('db_conn.php');  
    $userid = $_POST['username'];  
    $password = $_POST['password'];  
      
   
        $sql = "SELECT * FROM `user` where `email` = '$userid' and `password` = '$password' and `verification_status` = '1' ";  
        $result = mysqli_query($conn, $sql); 
        $count = mysqli_num_rows($result);  
      
        if($count == 1){  
          $_SESSION['email'] = $userid;
          echo '<script>alert("Login success");window.location.assign("home.php");</script>';  
          die();
        }  
        else{  
            echo '<script>alert(" Invalid UserID or Password");window.location.assign("index.php");</script>';  
        } 
   
?>  
 
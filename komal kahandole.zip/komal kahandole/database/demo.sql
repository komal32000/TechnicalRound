-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jul 25, 2023 at 06:17 AM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.0.28

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `demo`
--

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `id` int(11) NOT NULL,
  `name` varchar(500) NOT NULL,
  `address` varchar(1000) NOT NULL,
  `phoneno` varchar(11) NOT NULL,
  `email` varchar(200) NOT NULL,
  `password` varchar(20) NOT NULL,
  `verification_id` varchar(100) NOT NULL,
  `verification_status` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`id`, `name`, `address`, `phoneno`, `email`, `password`, `verification_id`, `verification_status`) VALUES
(7, 'Test', '', '1234567890', 'komalkahandole@gmail.com', 'Test@123', 'fce408e2d5c866954212a7037006d191', '1'),
(8, 'Test', '', '1234567890', 'komalkahandole@gmail.com', 'asd123', 'f1de4efa1851397cdd1124d2fa640538', '0'),
(9, 'Test', '', '1234567890', 'komalkahandole@gmail.com', 'asd123', 'f966962822fa319fed9873ea3d252f5b', '0'),
(10, 'Test', '', '1234567890', 'komalkahandole@gmail.com', '123', '4cdc708b76193e96cbbd3461a31f42e4', '0'),
(11, 'Test', '', '1234567890', 'komalkahandole@gmail.com', 'asdwedc', '3bfd8a7d18c5f26bbf9a7d98b845a641', '0'),
(12, 'Test', '', '1234567890', 'komalkahandole@gmail.com', 'asdwedc', '8169aedcf615bb1d11acfc0f375e955e', '0'),
(13, 'Test', '', '1234567890', 'komalkahandole@gmail.com', 'asd', 'ab53173a4ecfb2d0cc4b06724f5c10da', '0'),
(14, 'Test', '', '1234567890', 'komalkahandole@gmail.com', 'asd', '365925ab341817567bf50bb13d27a478', '0');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
